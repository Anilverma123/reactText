import './App.css';
import Product from './Component/Product'

function App() {
  return (
    <div className="App">
     <Product/>
    </div>
  );
}

export default App;
