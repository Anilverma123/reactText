import React, { useState, useEffect } from 'react'

export default function Product() {
    const [product, setproduct] = useState([]);
    const getProduct = () => {
        let url = 'https://fakestoreapi.com/products/'

        fetch(url).then(resp => resp.json()).then(resp => setproduct(resp))
    }
    useEffect(() => {
        getProduct()
    })
    var elements = document.getElementsByClassName("column");

// Declare a loop variable
var i;

// List View
function listView() {
  for (i = 0; i < elements.length; i++) {
    elements[i].classList.add("listView");
    elements[i].classList.remove("gridView");
  }
}

// Grid View
function gridView() {
  for (i = 0; i < elements.length; i++) {
    elements[i].classList.add("gridView");
    elements[i].classList.remove("listView");
  }
}


    return (
        <div className='container'>
            <div id="btnContainer" className='mb-2 mt-2'>
  <button className="btn mr-2"  onClick={listView}><i className="fa fa-bars"></i> List</button> 
  <button className="btn"  onClick={gridView}><i className="fa fa-th-large"></i> Grid</button>
</div>
            <div className='row'>
                {
                    product.map((item, index) => {

                        return <div key={index}  className="col-sm-3 column">
                            <div className="card">
                                <div className='image_blck'><img src={item.image} alt="image"/></div>
                            <div className="card-body">
                                <h4 className="card-title textData ">{item.title}</h4>
                                <p className="card-text textData">{item.description}</p>
                                <p className="btn btn-outline-primary">Price:{item.price}</p>
                            </div>
                        </div>
                        </div>

                    })
                }
            </div>

        </div>

    )
}
